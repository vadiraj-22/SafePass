import React, { use, useCallback, useEffect, useRef, useState } from 'react'

const App = () => {
  // ===== Password Strength Checker State =====
  const [inputPassword, setInputPassword] = useState("");
  const [inputEntropy, setInputEntropy] = useState(0);
  const [inputStrength, setInputStrength] = useState("Weak");
  const [inputLeakedStatus, setInputLeakedStatus] = useState(null);
  const [inputIsChecking, setInputIsChecking] = useState(false);

  // ===== Password Generator State =====
  const [generatedPassword, setGeneratedPassword] = useState("");
  const [length, setLength] = useState(8);
  const [charAllowed, setCharAllowed] = useState(false);
  const [numAllowed, setNumAllowed] = useState(false);
  const [genEntropy, setGenEntropy] = useState(0);
  const [genStrength, setGenStrength] = useState("Weak");
  const [genLeakedStatus, setGenLeakedStatus] = useState(null);
  const [genIsChecking, setGenIsChecking] = useState(false);

  // ⭐ 1. Cryptographically Secure Random Generation
  const getSecureRandom = (max) => {
    const array = new Uint32Array(1);
    window.crypto.getRandomValues(array);
    return array[0] % max;
  }

  // ⭐ 2. Password Entropy Calculation
  const calculateEntropy = (pwd) => {
    if (!pwd || pwd.length === 0) return 0;

    // Determine character classes present in the password
    const hasLower = /[a-z]/.test(pwd);
    const hasUpper = /[A-Z]/.test(pwd);
    const hasDigit = /[0-9]/.test(pwd);
    const hasSymbol = /[^A-Za-z0-9]/.test(pwd);

    // Build an estimated charset size based on classes present
    let poolSize = 0;
    if (hasLower) poolSize += 26;
    if (hasUpper) poolSize += 26;
    if (hasDigit) poolSize += 10;
    if (hasSymbol) {
      // Estimate common printable symbol count (approx). Adjust if you have a known symbol set.
      poolSize += 32;
    }

    if (poolSize === 0) return 0;

    const entropyValue = pwd.length * Math.log2(poolSize);
    return Number(entropyValue.toFixed(2));
  }

  // Determine strength level based on entropy
  const getStrengthLevel = (entropyValue) => {
    if (entropyValue < 40) return "Weak";
    if (entropyValue < 60) return "Medium";
    if (entropyValue < 80) return "Strong";
    return "Military Grade";
  }

  // Get color based on strength
  const getStrengthColor = (strengthLevel) => {
    switch (strengthLevel) {
      case "Weak":
        return "bg-red-500";
      case "Medium":
        return "bg-yellow-500";
      case "Strong":
        return "bg-blue-500";
      case "Military Grade":
        return "bg-green-500";
      default:
        return "bg-gray-500";
    }
  }

  // ⭐ 4. Check password against HIBP (Have I Been Pwned)
  const checkPasswordBreach = async (pwd, isInputChecker = false) => {
    if (!pwd || pwd.length === 0) {
      if (isInputChecker) setInputLeakedStatus(null);
      else setGenLeakedStatus(null);
      return;
    }

    if (isInputChecker) setInputIsChecking(true);
    else setGenIsChecking(true);

    try {
      // Hash the password using SHA-1
      const encoder = new TextEncoder();
      const data = encoder.encode(pwd);
      const hashBuffer = await crypto.subtle.digest("SHA-1", data);
      
      // Convert to hex
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
      
      const firstFive = hashHex.substring(0, 5);
      const remaining = hashHex.substring(5);

      // Query HIBP API
      const response = await fetch(`https://api.pwnedpasswords.com/range/${firstFive}`);
      const text = await response.text();
      const lines = text.split('\r\n');

      let isLeaked = false;
      for (let line of lines) {
        const [hash, count] = line.split(':');
        if (hash === remaining) {
          isLeaked = true;
          const status = { leaked: true, count: parseInt(count) };
          if (isInputChecker) setInputLeakedStatus(status);
          else setGenLeakedStatus(status);
          break;
        }
      }

      if (!isLeaked) {
        const status = { leaked: false, count: 0 };
        if (isInputChecker) setInputLeakedStatus(status);
        else setGenLeakedStatus(status);
      }
    } catch (error) {
      console.error("Error checking breach:", error);
      const status = { error: "Could not check breach database" };
      if (isInputChecker) setInputLeakedStatus(status);
      else setGenLeakedStatus(status);
    } finally {
      if (isInputChecker) setInputIsChecking(false);
      else setGenIsChecking(false);
    }
  }

  // Handle input password change
  const handleInputPasswordChange = (e) => {
    const pwd = e.target.value;
    setInputPassword(pwd);
    
    // Calculate entropy
    const entropyValue = calculateEntropy(pwd);
    setInputEntropy(entropyValue);
    const strengthLevel = getStrengthLevel(entropyValue);
    setInputStrength(strengthLevel);
    
    // Check breach (debounced with 500ms delay for performance)
    const timer = setTimeout(() => {
      checkPasswordBreach(pwd, true);
    }, 500);

    return () => clearTimeout(timer);
  }

  const PasswordGenerater = useCallback(() => {
    let pass = ""
    let str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

    if (numAllowed) str += "0123456789"
    if (charAllowed) str += "~!@#$%^&*(){}:<>.,?|"

    for (let i = 1; i <= length; i++) {
      // ⭐ Using cryptographically secure random instead of Math.random()
      let char = getSecureRandom(str.length);
      pass += str.charAt(char)
    }
    setGeneratedPassword(pass)
    
    // Calculate entropy for new password
    const entropyValue = calculateEntropy(pass);
    setGenEntropy(entropyValue);
    const strengthLevel = getStrengthLevel(entropyValue);
    setGenStrength(strengthLevel);

    // Check if password is in breach database
    checkPasswordBreach(pass, false);
  }
    , [length, charAllowed, numAllowed])

  const generatedPasswordRef = useRef(null)

  const copyToClipboard = useCallback(() => {
    generatedPasswordRef.current?.select();
    window.navigator.clipboard.writeText(generatedPassword)
  }, [generatedPassword])

  useEffect(() => {
    PasswordGenerater()
  }, [length, numAllowed, charAllowed, PasswordGenerater])

  return (
    <div className='bg-black text-white min-h-screen p-8'>
      <div className='max-w-6xl mx-auto'>
        <h1 className='text-4xl font-bold text-center mb-2'>🔐 Password Security Suite</h1>
        <p className='text-center text-gray-400 mb-12'>Cybersecurity-Grade Tools for Password Management</p>

        <div className='grid grid-cols-1 lg:grid-cols-2 gap-8'>
          
          {/* ===== SECTION 1: PASSWORD STRENGTH CHECKER ===== */}
          <div className='bg-gray-800 p-8 rounded-xl'>
            <h2 className='text-2xl font-bold mb-6 flex items-center gap-2'>
              🔍 Password Strength Checker
            </h2>
            
            <div className='mb-6'>
              <label className='block text-sm font-semibold mb-2'>Enter Your Password</label>
              <input 
                type="password"
                placeholder='Type password to analyze...'
                value={inputPassword}
                onChange={handleInputPasswordChange}
                className='w-full bg-gray-900 text-white py-3 rounded-lg px-4 border border-gray-700 focus:border-blue-500 focus:outline-none transition'
              />
            </div>

            {inputPassword && (
              <>
                {/* Strength Meter */}
                <div className='bg-gray-900 p-4 rounded-lg mb-4'>
                  <div className='flex justify-between mb-2'>
                    <span className='text-sm font-semibold'>Strength</span>
                    <span className={`text-sm font-bold ${
                      inputStrength === "Weak" ? "text-red-500" :
                      inputStrength === "Medium" ? "text-yellow-500" :
                      inputStrength === "Strong" ? "text-blue-500" :
                      "text-green-500"
                    }`}>{inputStrength}</span>
                  </div>
                  <div className='w-full bg-gray-700 rounded-full h-3 overflow-hidden'>
                    <div className={`h-full transition-all ${getStrengthColor(inputStrength)}`}
                      style={{width: `${Math.min((inputEntropy / 100) * 100, 100)}%`}}></div>
                  </div>
                </div>

                {/* Metrics */}
                <div className='grid grid-cols-3 gap-3 mb-4 text-xs'>
                  <div className='bg-gray-900 p-3 rounded text-center'>
                    <p className='text-gray-400'>Length</p>
                    <p className='text-lg font-bold'>{inputPassword.length}</p>
                  </div>
                  <div className='bg-gray-900 p-3 rounded text-center'>
                    <p className='text-gray-400'>Diversity</p>
                    <p className='text-lg font-bold'>{new Set(inputPassword).size}</p>
                  </div>
                  <div className='bg-gray-900 p-3 rounded text-center'>
                    <p className='text-gray-400'>Entropy</p>
                    <p className='text-lg font-bold'>{inputEntropy}</p>
                  </div>
                </div>

                {/* Breach Status */}
                <div className='bg-gray-900 p-3 rounded text-sm'>
                  {inputIsChecking && <p className='text-yellow-400'>🔍 Checking breach database...</p>}
                  {!inputIsChecking && inputLeakedStatus && (
                    <>
                      {inputLeakedStatus.error ? (
                        <p className='text-gray-400'>{inputLeakedStatus.error}</p>
                      ) : inputLeakedStatus.leaked ? (
                        <p className='text-red-500 font-semibold'>⚠️ Found in {inputLeakedStatus.count} breaches</p>
                      ) : (
                        <p className='text-green-500 font-semibold'>✅ Safe - No breaches found</p>
                      )}
                    </>
                  )}
                </div>
              </>
            )}
          </div>

          {/* ===== SECTION 2: RANDOM PASSWORD GENERATOR ===== */}
          <div className='bg-gray-800 p-8 rounded-xl'>
            <h2 className='text-2xl font-bold mb-6 flex items-center gap-2'>
              ⚡ Random Password Generator
            </h2>

            {/* Generated Password Display */}
            <div className='flex gap-3 mb-6'>
              <input 
                type="text"
                className='flex-1 bg-gray-900 text-white py-3 rounded-lg px-4 border border-gray-700 font-mono text-sm'
                readOnly
                ref={generatedPasswordRef}
                value={generatedPassword}
              />
              <button 
                className='bg-green-500 hover:bg-green-600 text-black font-semibold py-3 px-6 rounded-lg transition'
                onClick={copyToClipboard}
              >📋 Copy</button>
            </div>

            {/* Controls */}
            <div className='mb-6 space-y-4'>
              <div>
                <div className='flex justify-between mb-2'>
                  <label className='text-sm font-semibold'>Length: {length}</label>
                  <span className='text-xs text-gray-400'>{length} characters</span>
                </div>
                <input 
                  type="range"
                  min={8}
                  max={100}
                  value={length}
                  onChange={(e) => setLength(e.target.value)}
                  className='w-full'
                />
              </div>

              <div className='flex gap-6'>
                <label className='flex items-center gap-2 cursor-pointer'>
                  <input 
                    type="checkbox"
                    checked={numAllowed}
                    onChange={() => setNumAllowed(!numAllowed)}
                    className='w-4 h-4'
                  />
                  <span className='text-sm'>Numbers (0-9)</span>
                </label>
                <label className='flex items-center gap-2 cursor-pointer'>
                  <input 
                    type="checkbox"
                    checked={charAllowed}
                    onChange={() => setCharAllowed(!charAllowed)}
                    className='w-4 h-4'
                  />
                  <span className='text-sm'>Symbols (~!@#$%...)</span>
                </label>
              </div>
            </div>

            {/* Generator Strength Meter */}
            {generatedPassword && (
              <>
                <div className='bg-gray-900 p-4 rounded-lg mb-4'>
                  <div className='flex justify-between mb-2'>
                    <span className='text-sm font-semibold'>Generated Password Strength</span>
                    <span className={`text-sm font-bold ${
                      genStrength === "Weak" ? "text-red-500" :
                      genStrength === "Medium" ? "text-yellow-500" :
                      genStrength === "Strong" ? "text-blue-500" :
                      "text-green-500"
                    }`}>{genStrength}</span>
                  </div>
                  <div className='w-full bg-gray-700 rounded-full h-3 overflow-hidden'>
                    <div className={`h-full transition-all ${getStrengthColor(genStrength)}`}
                      style={{width: `${Math.min((genEntropy / 100) * 100, 100)}%`}}></div>
                  </div>
                </div>

                {/* Generator Metrics */}
                <div className='grid grid-cols-3 gap-3 mb-4 text-xs'>
                  <div className='bg-gray-900 p-3 rounded text-center'>
                    <p className='text-gray-400'>Length</p>
                    <p className='text-lg font-bold'>{length}</p>
                  </div>
                  <div className='bg-gray-900 p-3 rounded text-center'>
                    <p className='text-gray-400'>Diversity</p>
                    <p className='text-lg font-bold'>{new Set(generatedPassword).size}</p>
                  </div>
                  <div className='bg-gray-900 p-3 rounded text-center'>
                    <p className='text-gray-400'>Entropy</p>
                    <p className='text-lg font-bold'>{genEntropy}</p>
                  </div>
                </div>

                {/* Generator Breach Status */}
                <div className='bg-gray-900 p-3 rounded text-sm'>
                  {genIsChecking && <p className='text-yellow-400'>🔍 Checking breach database...</p>}
                  {!genIsChecking && genLeakedStatus && (
                    <>
                      {genLeakedStatus.error ? (
                        <p className='text-gray-400'>{genLeakedStatus.error}</p>
                      ) : genLeakedStatus.leaked ? (
                        <p className='text-red-500 font-semibold'>⚠️ Found in {genLeakedStatus.count} breaches</p>
                      ) : (
                        <p className='text-green-500 font-semibold'>✅ Safe - No breaches found</p>
                      )}
                    </>
                  )}
                </div>
              </>
            )}
          </div>

        </div>
      </div>
    </div>
  )
}

export default App